## Clean Architecture Principles

- **Separation of Concerns**: Each part of the application has a specific responsibility
- **Dependency Rule**: Dependencies always point inward
- **Abstraction**: Inner layers don't know about outer layers
- **Testability**: Business logic can be tested independently of UI or external services

## Base Architecture

The application structured is based on clean architecture, with the following main folders:

- Core/
- Data/
- Domain/
- Presentation/
- enviroments/
- main_injector.dart
- main_app.dart
- main.dart

### Core

Contains essential infrastructure for the application functioning:

- constants/: Application-wide constants
- localization/: App lengauges support
- navigation/: Navigation configuration
- services/: Core services like analytics, logging, etc.
- theme/: Style definitions
- utils/: Helper functions and extensions (for services)
- etc.

### Data

Contains files used for data extraction or API connections, as well as necessary mappers to convert this data into different models or variables.
Uses the "repository" design pattern for data handling.

- repositories/
- dtos/: DTOs (Data Transfer Objects)
- utils/: Utils to transform received data into new data such StringToEnity, etc (file_data_utils.dart)

### Domain

Contains the necessary files that represent business models or entities.

- models/: Entity models (These models have basic mappers)
- utils/: Files to extract data for complex models, for example getProductName from Model, etc (model_utils.dart)

Note this architecture does not implement model abstraction or use cases, this is for personal opinion and for me makes eaasier to maintain this proyect architecture

### Presentation

- Contains files necessary for application state management, shared widgets, screens, and general views.

- screens/: Full pages with scaffolds and app bars
  - Views/: Content of screens without scaffolding
    - File structure within this folder:
      - file_bloc_listener: For bloc state management listener configurations.
      - file_screen: Contains the code that represents the screen, including the appbar and main design.
      - file_view: Contains the code of what the screen displays, without the appbar or main scaffold.
      - widgets/: Folder containing specific widgets for the module, view, or screen.
- widgets/: Shareable and reusable UI components
- blocs/: State management

### Environments

- Contains configuration for development and production environments.
- Located in lib/environments with 4 files:

  - env_config_dev.dart: Contains variable values for the dev environment.
  - env_config_prod.dart: Contains variable values for the production environment.
  - env_config_stg.dart: Contains variable values for the staging environment.
  - env_config.dart: Configuration file that detects the app's flavor.
  - env_vars.dart: Contains the abstraction of variables to be used.

  HOW THIS WORKS:

  - we going to use dart define variables and flavors, depending of the flavor we going to use enviroment vars to have a unique main entry point

### Additional Files

- main_injector.dart: Dependency injection setup
- main_app.dart: Root Material App configuration
- main.dart: Application bootstrap

## Development Process

When developing a new feature:

(Remember some steps are not necessary, so skip them if needed)

1. Define a entity model
1. Create a service
1. Create a repository
1. Create state management files for the module and connect repository
1. Create ui and connect state manager

# Creating a service

1. Create the service in lib/services for encapsulation if possible.
2. Add the external dependency in lib/main_injector.
3. Add the created service in lib/core/services/services_injector.dart.

# Creating repository

1. Create the repository in lib/data/repositories/name_repository.dart if needed.
2. Add the repository to lib/data/repositories/repositories_injector.dart.

# Creating state manageer

in this case we use bloc

1. Create the corresponding bloc or state in lib/presentation.
2. Add the created bloc to lib/presentation/blocs/bloc_injector.dart.
3. if is a global state, add the created bloc to lib/presentation/blocs/app_bloc_provider.dart.
4. Create necessary screens and widgets in lib/presentation/screens and lib/presentation/widgets.

## Dependency Management

- get_it: Service locator for dependency injection
- Bloc: State management
- go_router: Navigation
- Formz: Form management
- dio: HTTP client

## Additional Information

- Uses get_it package as a service locator for dependency injection.
- The main file for services, repositories, blocs, etc., is /lib/main_injector.dart.
- Uses Bloc for state management, go_router for navigation, Formz for forms managent, and dio as API client.

## Additional Considerations

- Encapsulate external dependencies to avoid strong coupling
- Handle sensitive data securely
- Consider accessibility in UI design
- Document complex business logic

# ===================================

# ===================================

===================================

# Project Structure

This project follows a clean and organized structure to maintain scalability and separation of concerns.

## Directory Structure

```
lib/
├── core/              # Core functionality and configurations
├── data/              # Data handling and external interactions
├── domain/            # Business logic and entities
└── presentation/      # UI layer components
```

## Core Layer

Contains application-wide configurations and utilities.

```
core/
├── environments/      # Environment configurations (dev, prod)
├── localization/      # Internationalization files
├── navigation/        # Route management
├── services/          # Global services (image_picker, logging)
├── theme/            # App theming and styling
└── utils/            # Core utilities and helpers
```

### Core Utils vs Data Utils

- **Core Utils**: Pure utility functions that don't depend on data structures or models

  - Date formatting for display
  - String manipulations
  - Validation helpers
  - Generic formatters (currency, phone numbers)
  - Constants and enums

- **Data Utils**: Helpers specific to data handling and transformations
  - API response parsing
  - Data structure transformations
  - Storage helpers
  - Data-specific formatters

## Data Layer

Handles data operations and external interactions.

```
data/
├── models/           # Data models (API responses, local storage)
├── repositories/     # Data operations implementation
└── utils/           # Data-specific utilities
```

### Data Models vs Domain Models

- **Data Models** (`data/models/`):
  - Represent data as it comes from external sources
  - Include JSON serialization logic
  - Handle API-specific structures
  - May contain additional fields needed for data operations
  - Example: `UserModel` with API-specific fields

```dart
class UserModel {
    final String id;
    final String email;
    final String lastLoginTimestamp;

    factory UserModel.fromJson(Map<String, dynamic> json) { ... }
    Map<String, dynamic> toJson() { ... }
    User toDomain() { ... }  // Converts to domain model
}
```

- **Domain Models** (`domain/models/`):
  - Pure business entities
  - No external dependencies
  - Represent core business concepts
  - Contains only essential business fields
  - Example: `User` with core business fields

```dart
class User {
    final String id;
    final String email;
    final DateTime lastLogin;  // Converted to business-friendly type
}
```

## Domain Layer

Contains the core business logic and entities.

```
domain/
└── models/           # Business entities
```

## Presentation Layer

Handles all UI-related components.

```
presentation/
├── blocs/           # Business Logic Components
├── screens/         # Full screens/pages
└── widgets/         # Reusable UI components
```

## Main Dependencies

- State Management: flutter_bloc
- Navigation: go_router
- Localization: flutter_localizations

# Internationalization (i18n)

This project uses Flutter's built-in internationalization support with ARB files.

## Initial Setup

When cloning the repository for the first time:

1. Install dependencies:

```bash
flutter pub get
```

2. Generate localization files:

```bash
flutter gen-l10n
```

This will generate the necessary Dart files in `lib/core/localization/generated/`.

## Project Structure

```
lib/core/localization/
├── l10n/                # Translation files
│   ├── app_en.arb      # English translations
│   └── app_es.arb      # Spanish translations
├── generated/          # Auto-generated files
├── extensions/         # Localization extensions
└── ...
```

## Usage in Code

Use the extension method for easy access to translations:

```dart
import 'package:your_app/core/localization/extensions/localization_extension.dart';

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(context.l10n.someText);
  }
}
```

## Adding a New Language

1. Create a new ARB file in `lib/core/localization/l10n/` following the naming convention:

```bash
app_<language_code>.arb
```

For example, for French:

```bash
app_fr.arb
```

2. Copy the content structure from `app_en.arb` and translate the values:

```json
{
  "@@locale": "fr",
  "appTitle": "Nom de l'application",
  "welcomeMessage": "Bienvenue",
  "save": "Enregistrer",
  "cancel": "Annuler"
}
```

3. Add the new locale to supported locales in your app:

```dart
supportedLocales: const [
  Locale('en'),
  Locale('es'),
  Locale('fr'),  // Add new locale here
],
```

4. Regenerate the localization files:

```bash
flutter gen-l10n
```

## Language Resolution

The app will:

1. First try to use the device's language if supported
2. If not supported, fall back to Spanish (es)

This is configured in the MaterialApp:

```dart
localeResolutionCallback: (locale, supportedLocales) {
  if (locale != null) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return locale;
      }
    }
  }
  return const Locale('es');
},
```

## Modifying Existing Translations

1. Locate the appropriate ARB file in `lib/core/localization/l10n/`
2. Update the translation value
3. Run `flutter gen-l10n` to regenerate files
4. Test the changes in the app

## Best Practices

1. Keep keys descriptive and organized
2. Always provide translations for all supported languages
3. Test the app in all supported languages
4. Run `flutter gen-l10n` after any changes to ARB files

# Theme System

This document explains how the theme system works, including color management and additional colors outside the theme.

## Directory Structure

```
lib/core/theme/
├── extensions/
│   ├── colors_extension.dart    # Extensions for additional colors
│   └── theme_extension.dart     # Extensions for theme colors
├── themes/
│   ├── dark_theme.dart         # Dark theme configuration
│   └── light_theme.dart        # Light theme configuration
├── app_colors.dart            # Base color definitions
└── app_theme.dart            # Theme configuration
```

## Color System Overview

The color system is organized in three layers of abstraction:

1. **Theme Colors** (Primary usage)

   - Access via `context.colorScheme`
   - Used for most UI elements
   - Automatically handles light/dark modes

2. **Additional Colors** (Secondary usage)

   - Access via `context.colors`
   - For colors needed in the app but not part of the theme
   - Includes light/dark variants

3. **Base Colors** (Avoid direct usage)
   - Defined in `app_colors.dart`
   - Should rarely be used directly
   - Serves as the source for theme and additional colors

## Extensions

### Theme Colors Extension

```dart
// lib/core/theme/extensions/theme_extension.dart
import 'package:flutter/material.dart';

extension ThemeColorsX on BuildContext {
  ThemeData get theme => Theme.of(this);
  ColorScheme get colorScheme => theme.colorScheme;
}
```

### Additional Colors Extension

```dart
// lib/core/theme/extensions/colors_extension.dart
import 'package:flutter/material.dart';
import '../app_colors.dart';

extension ColorsExtension on BuildContext {
  ColorDataExtension get colors => ColorDataExtension(this);
}
```

## Usage Examples

### Theme Colors (Preferred)

```dart
import 'package:your_app/core/theme/extensions/theme_extension.dart';

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: context.colorScheme.surface,
      child: Text(
        'Hello',
        style: TextStyle(color: context.colorScheme.onSurface),
      ),
    );
  }
}
```

### Additional Colors

```dart
import 'package:your_app/core/theme/extensions/colors_extension.dart';

class MyWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: context.colors.container01,
      child: Text('Special content'),
    );
  }
}
```

## Adding New Colors

### Adding to Theme System

```dart
// lib/core/theme/themes/light_theme.dart or dark_theme.dart
import 'package:flutter/material.dart';
import '../app_colors.dart';

class LightTheme {
  static final colorScheme = ColorScheme(
    // Add to appropriate color role
  );
}
```

### Adding Additional Colors

```dart
// 1. First add to lib/core/theme/app_colors.dart
abstract class AppColors {
  static const newColorLight = Color(0xFF...);
  static const newColorDark = Color(0xFF...);
}

// 2. Then add to lib/core/theme/extensions/colors_extension.dart
class ColorDataExtension {
  final BuildContext context;

  ColorDataExtension(this.context);

  Color get newColor {
    return Theme.of(context).brightness == Brightness.dark
        ? AppColors.newColorDark
        : AppColors.newColorLight;
  }
}
```

## Best Practices

1. **Theme First Approach**

```dart
import 'package:your_app/core/theme/extensions/theme_extension.dart';

// ✅ Good: Using theme colors
Text(
  'Hello',
  style: TextStyle(color: context.colorScheme.primary),
)

// ❌ Bad: Direct usage of AppColors
Text(
  'Hello',
  style: TextStyle(color: AppColors.royalBlue),
)
```

2. **Additional Colors When Needed**

```dart
import 'package:your_app/core/theme/extensions/colors_extension.dart';

// ✅ Good: Using additional colors through extension
Container(
  color: context.colors.container01,
)

// ❌ Bad: Direct color usage
Container(
  color: AppColors.container01Light,
)
```

## Configuration in MaterialApp

```dart
import 'package:your_app/core/theme/app_theme.dart';

MaterialApp(
  theme: AppTheme.light,
  darkTheme: AppTheme.dark,
  // Optional: force a specific theme
  // themeMode: ThemeMode.system, // .light or .dark
)
```

# Flutter Icon System

## Structure

```
project/
├── assets/
│   └── icons/          # SVG icon files
│       ├── home.svg
│       ├── menu.svg
│       └── search.svg
├── lib/
│   └── core/
│       └── theme/
│           └── icons/
│               ├── app_icon_name.dart  # Generated enum
│               ├── app_icon.dart       # Widget implementation
│               └── index.dart          # Exports
└── tool/
    └── generate_icons.dart  # Generator script
```

## Setup

1. **Create Directory Structure**

   ```bash
   mkdir -p assets/icons
   mkdir -p lib/core/theme/icons
   mkdir -p tool
   ```

2. **Add Generator Script**
   Create `tool/generate_icons.dart`:

   ```dart
   // tool/generate_icons.dart
   import 'dart:io';

   void main() {
     final iconFiles = Directory('assets/icons')
         .listSync()
         .whereType<File>()
         .where((file) => file.path.toLowerCase().endsWith('.svg'))
         .map((file) => file.uri.pathSegments.last.replaceAll('.svg', ''))
         .toList()
       ..sort();

     final buffer = StringBuffer();
     buffer.writeln('''
   // GENERATED CODE - DO NOT MODIFY BY HAND
   // ignore_for_file: constant_identifier_names

   /// Available icons in the application.
   /// This enum is generated automatically from the SVG files in assets/icons directory.
   /// Used by [AppIcon] widget to display SVG icons consistently across the app.
   enum AppIconName {''');
     buffer.writeln(iconFiles.join(',\n  '));
     buffer.writeln('}');

     final outputDir = Directory('lib/core/theme/icons');
     outputDir.createSync(recursive: true);
     File('lib/core/theme/icons/app_icon_name.dart').writeAsStringSync(buffer.toString());
   }
   ```

3. **Create Widget Implementation**
   Create `lib/core/theme/icons/app_icon.dart`:

   ```dart
   import 'package:flutter/widgets.dart';
   import 'package:flutter_svg/flutter_svg.dart';
   import 'app_icon_name.dart';

   class AppIcon extends StatelessWidget {
     static const String _basePath = 'assets/icons';

     final AppIconName icon;
     final double? size;
     final double? width;
     final double? height;
     final Color? color;
     final BlendMode colorBlendMode;

     const AppIcon(
       this.icon, {
       super.key,
       this.size,
       this.width,
       this.height,
       this.color,
       this.colorBlendMode = BlendMode.srcIn,
     });

     @override
     Widget build(BuildContext context) {
       return SvgPicture.asset(
         '$_basePath/${icon.name}.svg',
         width: width ?? size,
         height: height ?? size,
         colorFilter: color != null ? ColorFilter.mode(color, colorBlendMode) : null,
       );
     }
   }
   ```

4. **Create Index File**
   Create `lib/core/theme/icons/index.dart`:

   ```dart
   export 'app_icon.dart';
   export 'app_icon_name.dart';
   ```

5. **Update pubspec.yaml**

   ```yaml
   dependencies:
     flutter_svg: ^latest_version

   flutter:
     assets:
       - assets/icons/
   ```

## Usage

1. **Add SVG Icons**
   Place your SVG files in `assets/icons/` directory.

2. **Generate Enum**
   Run the generator:

   ```bash
   dart run tool/generate_icons.dart
   ```

3. **Use in Code**

   ```dart
   import 'package:your_app/core/theme/icons/index.dart';

   // Basic usage
   AppIcon(AppIconName.menu)

   // With size
   AppIcon(
     AppIconName.home,
     size: 24,
   )

   // With color
   AppIcon(
     AppIconName.search,
     size: 24,
     color: Colors.blue,
   )

   // In IconButton
   IconButton(
     icon: AppIcon(AppIconName.menu),
     onPressed: () {},
   )

   // Custom dimensions
   AppIcon(
     AppIconName.cloud,
     width: 32,
     height: 24,
   )
   ```

## Maintenance

- To add new icons:

  1. Add SVG file to `assets/icons/`
  2. Run generator
  3. Icons are automatically available via `AppIconName` enum

- To update existing icons:

  1. Replace SVG file in `assets/icons/`
  2. No need to run generator unless filename changes

- To remove icons:
  1. Delete SVG file from `assets/icons/`
  2. Run generator
  3. Icon will be removed from `AppIconName` enum

## Best Practices

1. Use meaningful and consistent icon names
2. Keep SVG files optimized and clean
3. Run generator after any changes to icons
4. Use the index.dart for imports
5. Default to using `size` parameter unless specific width/height needed

# Flutter Text Styles System

## File Structure

```
lib/
├── theme/
│   ├── extensions/
│   │   ├── colors_extensions.dart
│   │   ├── textstyles_extension.dart
│   │   └── theme_extensions.dart
│   └── fonts/
│       ├── poppins.dart
│       └── roboto.dart
```

## Overview

A simple and flexible system to handle text styles in Flutter using BuildContext extensions.

Recomended use clamps to handle better font sizes

## Main Components

### textstyles_extension.dart

```dart
extension TextStyleExtension on BuildContext {
  TextStyles get textstyles => TextStyles();
}

class TextStyles {
  final roboto = Roboto.instance;
  // final poppins = Poppins.instance; // as example When needed
}
```

### fonts/roboto.dart

Defines text styles for Roboto font (Material's default font).

```dart
class Roboto {
  static final instance = Roboto._();
  Roboto._();

  final TextStyle h1Black = const TextStyle(
    fontFamily: 'Roboto',
    fontSize: 32,
    fontWeight: FontWeight.w900,
  );
  // ... more styles
}
```

### fonts/poppins.dart

Template for adding Poppins font (or any other).

```dart
class Poppins {
  static final instance = Poppins._();
  Poppins._();

  final TextStyle h1Black = const TextStyle(
    fontFamily: 'Poppins',
    fontSize: 32,
    fontWeight: FontWeight.w900,
  );
  // ... more styles
}
```

## Usage

### Basic Access

```dart
Text('Title', style: context.textstyles.roboto.h1Black)
```

### Available Styles

Each font provides these styles by default:

- `h1Black`: Size 32, weight 900
- `h1Medium`: Size 32, weight 500
- `h3Medium`: Size 24, weight 500

Note: You can add as many custom styles as needed. While the naming convention is flexible (e.g., `titleBold`, `bodyRegular`, `captionLight`), it's recommended to maintain consistency across your project. Some suggested patterns:

- Size + Weight: `h1Black`, `h2Medium`, `h3Light`
- Purpose + Weight: `titleBold`, `subtitleMedium`, `bodyRegular`
- Semantic + Weight: `primaryBold`, `secondaryMedium`, `accentLight`

## Adding a New Font

1. Create a new file in `theme/fonts/` (e.g., `new_font.dart`)
2. Implement the class following the singleton pattern:

```dart
class NewFont {
  static final instance = NewFont._();
  NewFont._();

  // Define styles...
}
```

3. Add the instance in `TextStyles`:

```dart
class TextStyles {
  final roboto = Roboto.instance;
  final newFont = NewFont.instance;
}
```

## pubspec.yaml Configuration

For custom fonts, add to `pubspec.yaml`:

```yaml
flutter:
  fonts:
    - family: FontName
      fonts:
        - asset: assets/fonts/Font-Black.ttf
          weight: 900
        - asset: assets/fonts/Font-Medium.ttf
          weight: 500
```

# Core Logger

Flutter logging system that handles local logs and reporting to external services like Crashlytics or Sentry, with support for additional data and error deduplication.

## Project Structure

```
lib/
  core/
    logger/
      ├── log_reporter/
      │   ├── log_reporter.dart           # Base interface for reporters
      │   ├── crashlytics_log_reporter.dart    # Example Crashlytics implementation
      │   └── sentry_log_reporter.dart         # Example Sentry implementation
      ├── reported_error.dart     # Wrapper class for reported errors
      └── app_logger.dart         # Main logger implementation
```

## Main Components

### 1. AppLogger (app_logger.dart)

Main logging class with static methods:

```dart
// Info log (debug only)
AppLogger.i("Message");

// Warning log (debug only)
AppLogger.w("Warning");

// Error log (debug and release)
AppLogger.e("Error", error, stackTrace);
```

### 2. LogReporter (log_reporter/log_reporter.dart)

Interface that defines how logs are reported to external services:

```dart
abstract class LogReporter {
  void logError(dynamic error, [StackTrace? stackTrace, Map<String, dynamic>? data]);
  void logInfo(String message, [Map<String, dynamic>? data]);
  void logWarning(String message, [Map<String, dynamic>? data]);
}
```

## Use Cases

### 1. Basic Logging

```dart
// Anywhere in your code
void loginUser() {
  try {
    AppLogger.i("Starting login process");  // Only visible in debug

    if (lowMemoryCondition) {
      AppLogger.w("Low memory while attempting login");  // Only visible in debug
    }

    // Some process that might fail
    throw Exception("Invalid credentials");
  } catch (e, stack) {
    // This error will be visible in debug and sent to reporter in release
    throw AppLogger.e("Login error", e, stack);
  }
}
```

### 2. Logging with Additional Data

```dart
// Log with specific data
AppLogger.i("User logged in", {
  'userId': '123',
  'email': 'user@example.com',
  'loginMethod': 'google'
});

// Global data for the entire session
AppLogger.setGlobalData({
  'deviceId': 'ABC123',
  'appVersion': '1.0.0',
  'buildNumber': '42'
});

// Add additional data to globals
AppLogger.addGlobalData({
  'networkType': 'wifi',
  'lastScreenView': 'HomeScreen'
});
```

### 3. Error Handling in Layers

```dart
// 1. API Layer
class ApiService {
  Future<void> fetchData() async {
    try {
      final response = await http.get(url);
      if (response.statusCode != 200) {
        throw HttpException('HTTP ${response.statusCode}');
      }
    } catch (e, stack) {
      // This error WILL be reported
      throw AppLogger.e(
        "API fetchData error",
        e,
        stack,
        {'url': url, 'statusCode': response.statusCode}
      );
    }
  }
}

// 2. Repository Layer
class UserRepository {
  Future<void> getUserData() async {
    try {
      await _apiService.fetchData();
    } catch (e, stack) {
      // This error WON'T be reported (already reported in API)
      throw AppLogger.e(
        "Repository getUserData error",
        e,
        stack,
        {'method': 'getUserData'}
      );
    }
  }
}

// 3. Bloc/Cubit Layer
class UserBloc {
  Future<void> loadUser() async {
    try {
      await _repository.getUserData();
    } catch (e, stack) {
      // This error WON'T be reported (already reported in API)
      AppLogger.e(
        "Bloc loadUser error",
        e,
        stack,
        {'state': 'loading'}
      );
      // Handle error...
    }
  }
}
```

### 4. Custom Reporter Implementation

```dart
import 'package:your_app/core/logger/log_reporter/log_reporter.dart';

class CustomReporter implements LogReporter {
  @override
  void logError(dynamic error, [StackTrace? stackTrace, Map<String, dynamic>? data]) {
    // Example: Send to custom monitoring service
    monitoringService.sendError(
      error: error,
      stackTrace: stackTrace,
      metadata: data,
      timestamp: DateTime.now(),
    );
  }

  @override
  void logInfo(String message, [Map<String, dynamic>? data]) {
    monitoringService.sendLog(
      level: 'INFO',
      message: message,
      metadata: data,
    );
  }

  @override
  void logWarning(String message, [Map<String, dynamic>? data]) {
    monitoringService.sendLog(
      level: 'WARNING',
      message: message,
      metadata: data,
    );
  }
}

// Usage
void initializeLogger() {
  final reporter = CustomReporter();
  AppLogger.setReporter(reporter);
}
```

## Global Error Handling Initialization

Here’s how to set up global error handlers to capture both Flutter framework errors and asynchronous errors throughout the application. Ensure this is called at the beginning of your application, typically in the `main` function.

```dart
/// Initializes global error handlers for the application.
static void initialize() {
  // Capture and log errors from the Flutter framework.
  FlutterError.onError = (FlutterErrorDetails details) {
    AppLogger.e(details.exceptionAsString(), details.exception, details.stack);
  };

  // Capture and log asynchronous errors across the platform.
  PlatformDispatcher.instance.onError = (error, stack) {
    AppLogger.e('Async Error', error, stack);
    return true; // Indicates that the error has been handled.
  };
}
```

You need to call the initialize method in the main function to ensure error handling is set up before running the app

```dart
void main() {
  // Initialize global error handling.
  AppLogger.initialize();

  // Run the Flutter application.
  runApp(MyApp());
}
```

## Behavior by Mode

### Debug Mode

- All logs (`i`, `w`, `e`) are shown in the console
- Errors are sent to the reporter if configured
- Includes full stack traces and additional data
- Logs include emojis and colors for better readability

### Release Mode

- Console logs are disabled
- Only errors (`e`) are sent to the reporter
- No performance impact from debug logs
- Additional data is only sent to the reporter

## Important Notes

1. The Crashlytics and Sentry implementations in the `log_reporter` folder are examples. You must implement the specific logic for your configuration.

2. To avoid error duplication, the system uses `ReportedError`:

   - An error is only reported the first time it passes through `AppLogger.e`
   - Subsequent reports of the same error are ignored
   - This prevents spam in your monitoring services

3. Global data persists until:

   - `clearGlobalData()` is called
   - The app is restarted
   - It's overwritten with `setGlobalData()`

4. In release mode, the logger is optimized to have zero performance impact when using `i()` and `w()`

# Flutter Android Flavor Support

## Implementation

Flavor support in the Flutter application (Android) is configured through three files:

### 1. android/app/flavor_config.gradle

File containing the flavors configuration (dev, stg, prod), defining suffixes and names for each environment.

### 2. android/app/build.gradle

```groovy
// Import flavors configuration
apply from: 'flavor_config.gradle'

android {
    ...
    // Apply configuration
    applyFlavors(android)
}
```

### 3. android/app/src/main/AndroidManifest.xml

```xml
<application
    android:label="@string/app_name"
    ... >
```

This configuration allows handling different application variants based on the development environment.

# Responsive Design Guide

This project implements responsive design using [responsive_sizer 3.3.1](https://pub.dev/packages/responsive_sizer/versions/3.3.1). This guide explains how to use the responsive units throughout the project.

## Responsive Units in Our Project

### Width (.w)

We use `.w` for proportional widths across the app:

```dart
// A card taking half the screen width
Card(
  width: 50.w,  // Always 50% of screen width
)
```

### Height (.h)

Height percentages are used for specific layout needs:

```dart
// Header height
Container(
  height: 10.h,  // Consistent 10% of screen height
)
```

### Density Pixels (.dp)

Our standard unit for consistent sizing across devices:

```dart
// Standard text and spacing in our app
Text(
  'Content',
  style: TextStyle(fontSize: 16.dp),  // Our standard body text size
)
```

### Layout Guidelines

When creating new screens:

1. **Container Widths**:

   ```dart
   Container(
     width: 90.w,  // Standard container width
     padding: EdgeInsets.all(16.dp),  // Standard padding
   )
   ```

2. **List Items**:

   ```dart
   ListTile(
     contentPadding: EdgeInsets.symmetric(
       horizontal: 16.dp,
       vertical: 8.dp,
     ),
   )
   ```

3. **Buttons**:
   ```dart
   ElevatedButton(
     padding: EdgeInsets.symmetric(
       horizontal: 16.dp,
       vertical: 8.dp,
     ),
     child: Text(
       'Button',
       style: TextStyle(fontSize: 16.dp),
     ),
   )
   ```

## Common Patterns

### Cards

```dart
Card(
  margin: EdgeInsets.all(16.dp),
  child: Container(
    width: 90.w,
    padding: EdgeInsets.all(16.dp),
    child: Text(
      'Card Content',
      style: TextStyle(fontSize: 16.dp),
    ),
  ),
)
```

### Form Fields

```dart
TextFormField(
  style: TextStyle(fontSize: 16.dp),
  decoration: InputDecoration(
    contentPadding: EdgeInsets.all(16.dp),
    labelStyle: TextStyle(fontSize: 14.dp),
  ),
)
```

## Device-Specific Adjustments

When needed, use Device.screenType for specific adjustments:

```dart
Container(
  padding: Device.screenType == ScreenType.mobile
    ? EdgeInsets.all(16.dp)
    : EdgeInsets.all(24.dp),
)
```

## Tips for Maintaining Consistency

1. Always use `.dp` for text sizes and spacing
2. Use `.w` for width-based layouts
3. Use `.h` sparingly, mainly for fixed-height components
4. Test layouts on both mobile and tablet views

# Flutter Environment Configuration System

This document describes the environment configuration system used in the application to manage different environments (Development, Staging, and Production).

## Overview

The system provides a flexible way to manage environment-specific configurations such as API URLs, feature flags, and other environment variables. It supports three environments out of the box:

- Development (dev)
- Staging (stg)
- Production (prod)

## File Structure

```
lib/
├── core/
│   └── environments/
│       ├── env_vars.dart         # Abstract base class defining environment variables
│       ├── env_config.dart       # Main configuration handler
│       ├── env_config_dev.dart   # Development environment configuration
│       ├── env_config_stg.dart   # Staging environment configuration
│       └── env_config_prod.dart  # Production environment configuration
```

## Implementation Details

### Base Configuration (env_vars.dart)

```dart
abstract class EnvVars {
  String get envName;
  String get apiUrl;
  // Add more environment variables as needed
}
```

### Environment-Specific Configurations

Each environment (dev, stg, prod) has its own configuration class implementing `EnvVars`:

```dart
class DevConfig implements EnvVars {
  @override
  String get envName => 'Development';

  @override
  String get apiUrl => 'https://api-dev.example.com';
}
```

### Configuration Handler (env_config.dart)

The `EnvConfig` class manages the environment selection and provides access to the current environment's configuration:

```dart
class EnvConfig {
  static const _flavor = String.fromEnvironment('FLAVOR', defaultValue: 'dev');
  static final EnvVars _instance = _getConfig();

  static EnvVars _getConfig() {
    switch (_flavor.toLowerCase()) {
      case 'prod':
        return ProdConfig();
      case 'stg':
        return StgConfig();
      default:
        return DevConfig();
    }
  }
}
```

## Usage

### Running the App

To run the app in a specific environment, use the `--dart-define` flag:

```bash
# Development
flutter run --dart-define=FLAVOR=dev

# Staging
flutter run --dart-define=FLAVOR=stg

# Production
flutter run --dart-define=FLAVOR=prod
```

### IDE Configuration (VS Code)

Add these configurations to your `launch.json`:

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Development",
      "request": "launch",
      "type": "dart",
      "args": ["--dart-define=FLAVOR=dev"]
    },
    {
      "name": "Staging",
      "request": "launch",
      "type": "dart",
      "args": ["--dart-define=FLAVOR=stg"]
    },
    {
      "name": "Production",
      "request": "launch",
      "type": "dart",
      "args": ["--dart-define=FLAVOR=prod"]
    }
  ]
}
```

### Using Environment Variables in Code

Access environment variables through the `EnvConfig` class:

```dart
// Get the API URL for the current environment
final apiUrl = EnvConfig.apiUrl;

// Check current environment
if (EnvConfig.isProd) {
  // Production-specific logic
} else if (EnvConfig.isStg) {
  // Staging-specific logic
} else {
  // Development-specific logic
}
```

## Adding New Environment Variables

To add a new environment variable, you need to follow these steps:

1. Add the new variable to the `EnvVars` abstract class:

```dart
abstract class EnvVars {
  String get envName;
  String get apiUrl;
  String get newVariable; // Add your new variable here
}
```

2. Add the getter in the `EnvConfig` class:

```dart
class EnvConfig {
  // ... existing code ...

  static String get envName => _instance.envName;
  static String get apiUrl => _instance.apiUrl;
  static String get newVariable => _instance.newVariable; // Add new getter
}
```

3. Implement the new variable in each environment configuration class:

````dart
// In env_config_dev.dart
class DevConfig implements EnvVars {
  @override
  String get envName => 'Development';

  @override
  String get apiUrl => 'https://api-dev.example.com';

  @override
  String get newVariable => 'dev-value';
}

// In env_config_stg.dart
class StgConfig implements EnvVars {
  @override
  String get envName => 'Staging';

  @override
  String get apiUrl => 'https://api-staging.example.com';

  @override
  String get newVariable => 'staging-value';
}

// In env_config_prod.dart
class ProdConfig implements EnvVars {
  @override
  String get envName => 'Production';

  @override
  String get apiUrl => 'https://api.example.com';

  @override
  String get newVariable => 'production-value';
}

## Adding New Environments

To add a new environment:

1. Create a new configuration class implementing `EnvVars`
2. Add the new case in the `_getConfig()` method in `EnvConfig`
3. Add a helper method in `EnvConfig` if needed

## Best Practices

1. Always use the `EnvConfig` class to access environment variables
2. Don't hardcode environment-specific values in the code
3. Keep sensitive information out of the configuration files
4. Document any new environment variables added to the system
5. Use meaningful names for environment variables

## Security Considerations

1. Never commit sensitive information (API keys, secrets) in these files
2. Use secure storage or environment variables for sensitive data
3. Consider using encryption for sensitive configuration values

## Building the App

### Development Builds

You can build the app in two ways:

1. Using only --dart-define:
```bash
# Without specifying flavor (defaults to dev)
flutter build apk

# Specifying environment
flutter build apk --dart-define=FLAVOR=dev
````

2. Using both Flutter flavors and dart-define (recommended):

```bash
# Development
flutter build apk --flavor dev --dart-define=FLAVOR=dev

# Staging
flutter build apk --flavor stg --dart-define=FLAVOR=stg

# Production
flutter build apk --flavor prod --dart-define=FLAVOR=prod
```

For release builds:

```bash
# Development
flutter build apk --release --flavor dev --dart-define=FLAVOR=dev

# Staging
flutter build apk --release --flavor stg --dart-define=FLAVOR=stg

# Production
flutter build apk --release --flavor prod --dart-define=FLAVOR=prod
```

Note: To use Flutter flavors (--flavor flag), you need to configure your Android and iOS projects accordingly:

For Android, in `android/app/build.gradle`:

```gradle
android {
    ...
    flavorDimensions "environment"
    productFlavors {
        dev {
            dimension "environment"
            applicationIdSuffix ".dev"
            resValue "string", "app_name", "App Dev"
        }
        stg {
            dimension "environment"
            applicationIdSuffix ".stg"
            resValue "string", "app_name", "App Stg"
        }
        prod {
            dimension "environment"
            resValue "string", "app_name", "App"
        }
    }
}
```

For iOS, you'll need to configure the schemes in Xcode accordingly.

### Split APKs by ABI

```bash
# Build split APKs for production
flutter build apk --release --split-per-abi --dart-define=FLAVOR=prod

# This will generate:
# - app-armeabi-v7a-release.apk
# - app-arm64-v8a-release.apk
# - app-x86_64-release.apk
```

### App Bundle

```bash
# Build app bundle for production
flutter build appbundle --release --dart-define=FLAVOR=prod
```

### iOS Builds

```bash
# Build iOS release
flutter build ios --release --dart-define=FLAVOR=prod
```

## Troubleshooting

Common issues and solutions:

1. **Wrong Environment Loading**: Verify the `--dart-define=FLAVOR` argument is correctly set
2. **Missing Variables**: Ensure all environment configurations implement all variables defined in `EnvVars`
3. **Build Issues**: Clean the project and rebuild if environment changes don't take effect
