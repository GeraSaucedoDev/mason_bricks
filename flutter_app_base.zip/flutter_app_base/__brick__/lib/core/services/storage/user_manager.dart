import 'dart:convert';
import 'package:{{app_name}}/core/services/storage/secure_storage_service.dart';
import 'package:{{app_name}}/domain/models/user.dart';

/// Manages secure storage operations for user data.
class UserManager {
  final SecureStorageService _storageService;
  static const String _userKey = 'user_data';

  UserManager(this._storageService);

  /// Retrieves and deserializes the user data from secure storage.
  /// Returns null if no user data exists.
  Future<User?> getUser() async {
    try {
      final userString = await _storageService.read<String>(key: _userKey);
      if (userString == null) return null;

      final userJson = jsonDecode(userString);
      return User.fromJson(userJson);
    } catch (e) {
      return null;
    }
  }

  /// Serializes and saves user data to secure storage.
  /// Throws if user object is invalid.
  Future<void> saveUser(User user) async {
    if (user.id == null) {
      throw Exception('Invalid user data cannot be saved');
    }
    final userString = jsonEncode(user.toJson());
    await _storageService.write<String>(key: _userKey, value: userString);
  }

  /// Removes user data from secure storage.
  Future<void> clearUserData() async {
    await _storageService.delete(key: _userKey);
  }
}
