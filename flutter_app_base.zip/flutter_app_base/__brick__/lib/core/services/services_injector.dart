import 'package:{{app_name}}/core/services/api/api_client.dart';
import 'package:{{app_name}}/core/services/storage/local_storage_service.dart';
import 'package:{{app_name}}/core/services/storage/secure_storage_service.dart';
import 'package:{{app_name}}/core/services/storage/token_manager.dart';
import 'package:{{app_name}}/core/services/storage/user_manager.dart';
import 'package:{{app_name}}/main_injector.dart';

/// Services that can be used in the app,
///
/// This method helps to inject the dependencies related to the services.
Future<void> servicesInjector() async {
  sl.registerLazySingleton(() => SecureStorageService(secureStorage: sl()));
  sl.registerLazySingleton(() => TokenManager(sl()));
  sl.registerLazySingleton(() => UserManager(sl()));
  sl.registerLazySingleton(() => LocalStorageService(storage: sl()));
  sl.registerLazySingleton(() => ApiClient(
        secureStorage: sl(),
        dio: sl(),
      ));
}
