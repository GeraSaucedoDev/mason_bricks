/* import 'package:{{app_name}}/core/services/logger/log_reporter/log_reporter.dart';

class SentryReporter implements LogReporter {
  @override
  void logError(dynamic error, [StackTrace? stackTrace]) {
    // Implementar la lógica de Sentry
    // Sentry.captureException(error, stackTrace: stackTrace);
  }

  @override
  void logInfo(String message) {
    // Sentry.addBreadcrumb(message: message);
  }

  @override
  void logWarning(String message) {
    // Sentry.addBreadcrumb(
    //   message: message,
    //   level: SentryLevel.warning,
    // );
  }
} */
