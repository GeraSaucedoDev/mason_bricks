/* import 'package:{{app_name}}/core/services/logger/log_reporter/log_reporter.dart';

class CrashlyticsReporter implements LogReporter {
  @override
  void logError(dynamic error, [StackTrace? stackTrace]) {
    // Implementar la lógica de Crashlytics
    // Firebase.crashlytics.recordError(error, stackTrace);
  }

  @override
  void logInfo(String message) {
    // Firebase.crashlytics.log(message);
  }

  @override
  void logWarning(String message) {
    // Firebase.crashlytics.log('WARNING: $message');
  }
} */
