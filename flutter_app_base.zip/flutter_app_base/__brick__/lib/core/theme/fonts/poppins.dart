//  Example font to be added

/*
import 'package:flutter/material.dart';
 
class Poppins {
  static final instance = Poppins._();
  Poppins._();

  final TextStyle h1Black = const TextStyle(
    fontFamily: 'Poppins',
    fontSize: 32,
    fontWeight: FontWeight.w900,
  );

  final TextStyle h1Medium = const TextStyle(
    fontFamily: 'Poppins',
    fontSize: 32,
    fontWeight: FontWeight.w500,
  );

  final TextStyle h3Medium = const TextStyle(
    fontFamily: 'Poppins',
    fontSize: 24,
    fontWeight: FontWeight.w500,
  );
}
*/

