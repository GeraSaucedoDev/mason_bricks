// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: constant_identifier_names

/// Available icons in the application.
/// This enum is generated automatically from the SVG files in assets/icons directory.
/// Used by [AppIcon] widget to display SVG icons consistently across the app.
enum AppIconName { cloud }
