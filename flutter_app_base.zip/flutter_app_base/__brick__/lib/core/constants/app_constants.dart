class AppConstants {
  static String appName = 'FlutterBaseApp';
}
