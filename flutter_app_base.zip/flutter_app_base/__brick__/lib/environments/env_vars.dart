abstract class EnvVars {
  String get envName;
}
