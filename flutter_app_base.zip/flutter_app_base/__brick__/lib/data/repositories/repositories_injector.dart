//import 'package:{{app_name}}/main_injector.dart';

void repositoriesInjector() {
/*   sl.registerLazySingleton(
    () => AuthRepository(
      apiClient: sl(),
      tokenManager: sl(),
      userService: sl(),
      configManager: sl(),
    ),
  );

  sl.registerLazySingleton(() => EsimRepository(apiClient: sl()));
  sl.registerLazySingleton(() => ProductsRepository(apiClient: sl()));
 */
}
