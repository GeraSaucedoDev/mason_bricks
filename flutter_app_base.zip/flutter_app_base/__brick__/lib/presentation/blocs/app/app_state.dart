part of 'app_bloc.dart';

class AppState extends Equatable {
  final String errorMessage;
  final bool isLoading;
  final bool dataLoaded;
  final User? user;

  const AppState({
    this.errorMessage = '',
    this.isLoading = false,
    this.dataLoaded = false,
    this.user,
  });

  @override
  List<Object?> get props => [
        errorMessage,
        isLoading,
        dataLoaded,
        user,
      ];

  AppState copyWith({
    String? errorMessage,
    bool? isLoading,
    bool? dataLoaded,
    User? user,
  }) {
    return AppState(
      errorMessage: errorMessage ?? this.errorMessage,
      isLoading: isLoading ?? this.isLoading,
      dataLoaded: dataLoaded ?? this.dataLoaded,
      user: user ?? this.user,
    );
  }
}
