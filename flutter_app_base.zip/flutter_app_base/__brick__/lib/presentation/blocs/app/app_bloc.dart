import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ftest_app/core/services/logger/app_logger.dart';
import 'package:ftest_app/domain/models/user.dart';

part 'app_events.dart';
part 'app_state.dart';

class AppBloc extends Bloc<AppEvent, AppState> {
  AppBloc()
      :
        // Bloc events
        super(const AppState()) {
    on<GetAppConfig>(_onGetAppConfig);
    on<CleanState>(_onCleanState);
    on<CleanError>(_onCleanError);
  }

  void _onGetAppConfig(
    GetAppConfig event,
    Emitter<AppState> emit,
  ) async {
    try {
      emit(state.copyWith(
        isLoading: true,
        dataLoaded: false,
        errorMessage: '',
      ));

      await Future.delayed(Duration(seconds: 1));

      final user = User();

      emit(state.copyWith(
        isLoading: false,
        dataLoaded: true,
        user: user,
      ));
    } catch (e, stack) {
      AppLogger.e('AppBloc | _onGetAppConfig()', e, stack);
      emit(state.copyWith(
        isLoading: false,
        errorMessage: 'Error al conectar con el servidor',
      ));
    }
  }

  void _onCleanError(CleanError event, Emitter<AppState> emit) {
    emit(state.copyWith(errorMessage: ''));
  }

  void _onCleanState(CleanState event, Emitter<AppState> emit) {
    emit(const AppState());
  }
}
