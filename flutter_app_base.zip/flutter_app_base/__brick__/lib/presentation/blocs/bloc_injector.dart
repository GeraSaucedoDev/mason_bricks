//import 'package:{{app_name}}/main_injector.dart';

void blocInjector() {
  //sl.registerFactory(() => LoginBloc(repository: sl(), userRepository: sl()));
  //sl.registerFactory(() => AuthBloc(authRepository: sl()));
}
